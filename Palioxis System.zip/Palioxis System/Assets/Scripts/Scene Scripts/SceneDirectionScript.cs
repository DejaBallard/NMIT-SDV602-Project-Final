﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//Script Purpose:
//Storing the location of scenes
//--------------------------------------- Start Of SceneDirectionScript Class ------------------------------------------------------------------------------
public class SceneDirectionScript{
    //--------------------------------------- Start Of Top Level Variable Decalaring ------------------------------------------------------------
    public string FromSceneName { get; set; }
    public string ToSceneName { get; set; }
    public string Direction { get; set; }
    //--------------------------------------- End Of Top Level Variable Declaring ---------------------------------------------------------


    //-------------------------------------- Start Of Methods ----------------------------------------------------------------------------	
    //-------------------------------------- End Of Methods ----------------------------------------------------------------------------	
}
//------------------------------------------ End Of SceneDirectionScript Class-------------------------------------------------------------------------------

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SQLite4Unity3d;
//Script Purpose:
//Storing Items in a scene

//--------------------------------------- Start Of SceneItem Class ------------------------------------------------------------------------------
public class SceneItemScript {
    //--------------------------------------- Start Of Top Level Variable Decalaring ------------------------------------------------------------
    public string SceneName { get; set; }
    public int ItemId { get; set; }
    //--------------------------------------- End Of Top Level Variable Declaring ---------------------------------------------------------


    //-------------------------------------- Start Of Methods ----------------------------------------------------------------------------	
    //-------------------------------------- End Of Methods ----------------------------------------------------------------------------	
}
//------------------------------------------ End Of SceneItem Class-------------------------------------------------------------------------------
